package com.example.cowork.models;

import java.io.Serializable;

public class Users implements Serializable {
    public String name, image, email, token;
}
