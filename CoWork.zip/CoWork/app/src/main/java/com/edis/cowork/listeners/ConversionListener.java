package com.edis.cowork.listeners;
import com.edis.cowork.models.User;

public interface ConversionListener {
    void onConversionClicked(User user);
}
