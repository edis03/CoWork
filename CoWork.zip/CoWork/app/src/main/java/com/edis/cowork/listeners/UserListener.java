package com.edis.cowork.listeners;
import com.edis.cowork.models.User;

public interface UserListener {
    void onUserClicked(User user);
}
